package org.vinh.constants;

/**
 * Description.
 * <p>
 * Author: Vinh Pham
 * Date: 04/04/2017
 * Time: 00:30
 */
public class SmsConstants {
    public static final String  SEND_MESSAGE = "/api/send-message";
}
