package org.vinh.services;

/**
 * Author: Vinh Pham
 * Date: 03/04/2017
 * Time: 12:41
 */
public class SmsGateWay {
    boolean postSms(String message){
        return true;
    }
}
